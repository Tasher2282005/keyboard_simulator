﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace keyboard_simulator
{
    public partial class Form2 : Form
    {
        int score = 0;
        int properly = 0;
        int mistake = 0;
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblCharacter.Top += 15;
            if(lblCharacter.Top >= gamePanel.Height)
            {
                lblCharacter.Location = GetNewPoint();
            }
        }
        Random xlocation = new Random();
        private Point GetNewPoint()
        {
            int x = xlocation.Next(0, gamePanel.Width-lblCharacter.Width);
            return new Point(x, 0);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            lblCharacter.Text = GetRandomCharacter().ToString();
            lblCharacter.Location = GetNewPoint();
            gameTimer.Start();
        }
        Random randomCharacter = new Random();
        private char GetRandomCharacter() 
        {
            return (char)randomCharacter.Next('а', 'я' + 1);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Ваш счет: {score} \nВы нажали правильно на {properly} клавиш \nОшиблись {mistake} раз"); 
            
            this.Close();
        }

        private void gamePanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char userPressKey = e.KeyChar;
            if(lblCharacter.Text == userPressKey.ToString())
            {
                properly += 1;
                score += 5;
                lblScore.Text = "Счет: " + score;
                lblCharacter.Location = GetNewPoint();
                lblCharacter.Text = GetRandomCharacter().ToString();

            }
            else
            {
                mistake += 1;
                score -= 5;
                lblScore.Text = "Счет: " + score;
            }
        }
    }
}
