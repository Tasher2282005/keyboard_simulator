﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {


        string[] words = { "компьютер", "клавиатура", "монитор", "мышь", "программирование", "разработка", "интернет", "браузер", "сайт", "сервер", "база данных", "облако", "мобильный", "приложение", "игра", "графика", "видео", "аудио", "сеть", "администрирование", "цифровой", "русский", "французский", "итальянский", "испанский" };
        Random rnd = new Random();

        int correct = 0;
        int incorrect = 0;




        public Form3()
        {
            InitializeComponent();

            label3.Text = words[rnd.Next(0, words.Length)];
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void game(object sender, KeyEventArgs e)
        {
            if( e.KeyCode == Keys.Enter)
            {
                if(textBox1.Text == label3.Text)
                {
                    correct++;
                    label3.Text = words[rnd.Next(0, words.Length)];
                    textBox1.Text = null;
                }
                else
                {
                    incorrect++;
                    label3.Text = words[rnd.Next(0, words.Length)];
                    textBox1.Text = null;
                }
                label1.Text = "Счет: " + correct;
                label2.Text = "Направильно: " + incorrect;

            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
